<?php $__env->startSection('content'); ?>
<div class="container">




    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">

                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <div class="card-header"><?php echo e(Auth('hotel')->user()->name); ?></div>

                <div class="card-body">

                        <div style="position: relative; height: 100%; width: 100%;">
                            <div class="">
                                <?php echo e($hotel->details); ?>

                            </div>
                            <div class="col-sm">
                                <img src="<?php echo e(asset('storage/'.$hotel->cover)); ?>">
                            </div>
                        </div>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.hotel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\giud\resources\views/hotel/show.blade.php ENDPATH**/ ?>