<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">

                <div class="card-header">Edit city</div>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('city.update',$city->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="card-body">
                            <div class="form-group row">
                                <label for="exampleInputEmail1" class="col-sm-2 col-form-label">City Name</label>
                                <div class="col-sm-10">
                                    <input name="name" type="text" class="form-control" id="inputEmail3" value="<?php echo e($city->name); ?>">
                                </div>
                            </div>

                            <input type="hidden" name="user_id" value="<?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>">

                            <?php if(count($countries)>0): ?>
                                <div class="form-group row">
                                    <label for="exampleInputEmail1" class="col-sm-2 col-form-label">Country Name</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" name="country_id">
                                            <option>select country</option>
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option class="form-control-file" value="<?php echo e($country->id); ?>" <?php echo e($city->country->id == $country->id ? 'selected' : ''); ?>><?php echo e($country->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary form-control">update</button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\giud\resources\views/backEnd/city/edit.blade.php ENDPATH**/ ?>